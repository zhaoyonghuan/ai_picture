import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { key } = await request.json()

    if (!key) {
      return NextResponse.json({ isValid: false, message: "未提供秘钥" }, { status: 400 })
    }

    // Simulate key validation logic
    // In a real app, you'd check this against a database
    await new Promise((resolve) => setTimeout(resolve, 500)) // Simulate network delay

    if (key === "VALID_KEY_123") {
      return NextResponse.json({ isValid: true })
    } else if (key === "USED_KEY_456") {
      return NextResponse.json({ isValid: false, message: "此秘钥已被使用" }, { status: 403 })
    } else {
      return NextResponse.json({ isValid: false, message: "秘钥无效" }, { status: 403 })
    }
  } catch (error) {
    console.error("Key validation API error:", error)
    return NextResponse.json({ isValid: false, message: "服务器内部错误" }, { status: 500 })
  }
}
