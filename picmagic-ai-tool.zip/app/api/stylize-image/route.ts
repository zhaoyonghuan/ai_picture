import { NextResponse } from "next/server"
import { styles } from "@/components/picmagic/picmagic-styles" // Assuming styles are accessible

export async function POST(request: Request) {
  try {
    const { imagePath, styleId, apiKey } = await request.json()

    if (!imagePath || !styleId || !apiKey) {
      return NextResponse.json({ message: "缺少必要参数 (imagePath, styleId, apiKey)" }, { status: 400 })
    }

    // Simulate API key check on the backend for this specific operation
    if (apiKey !== "VALID_KEY_123") {
      return NextResponse.json({ message: "秘钥无效或无权执行此操作" }, { status: 403 })
    }

    // Simulate AI image stylization process
    await new Promise((resolve) => setTimeout(resolve, 2500)) // Simulate AI processing time

    const selectedStyleDetails = styles.find((s) => s.id === styleId)
    const styleName = selectedStyleDetails ? selectedStyleDetails.name : "CustomStyle"

    // Simulate a successful response with a placeholder image URL
    // In a real app, this URL would point to the actual stylized image
    const stylizedImageUrl = `/placeholder.svg?width=512&height=512&text=Stylized:${encodeURIComponent(styleName)}`

    // Simulate a chance of failure for demonstration
    if (Math.random() < 0.15 && styleId !== "teddy") {
      // 15% chance of failure, but teddy always works
      return NextResponse.json({ message: `AI模型处理风格 "${styleName}" 时遇到问题，请稍后再试。` }, { status: 503 })
    }

    return NextResponse.json({ stylizedImageUrl })
  } catch (error) {
    console.error("Stylize image API error:", error)
    return NextResponse.json({ message: "图片风格化失败，服务器内部错误" }, { status: 500 })
  }
}
