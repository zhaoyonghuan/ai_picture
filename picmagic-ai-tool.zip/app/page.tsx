"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { KeyValidator } from "@/components/picmagic/key-validator"
import { ImageUploader } from "@/components/picmagic/image-uploader"
import { StyleSelector } from "@/components/picmagic/style-selector"
import { ResultDisplay } from "@/components/picmagic/result-display"
import { SupportModal } from "@/components/picmagic/support-modal"
import { useToast } from "@/hooks/use-toast" // 确保路径正确
import { Wand2, Upload } from "lucide-react" // Added Upload icon for clarity if needed

export default function PicMagicPage() {
  const [apiKey, setApiKey] = useState<string>("")
  const [isKeyValid, setIsKeyValid] = useState<boolean | null>(null)
  const [uploadedImage, setUploadedImage] = useState<File | null>(null)
  const [selectedStyle, setSelectedStyle] = useState<string | null>(null)

  const [generationStatus, setGenerationStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [isUploading, setIsUploading] = useState(false) // New state for upload status

  const [isSupportModalOpen, setIsSupportModalOpen] = useState(false)
  const { toast } = useToast()

  const handleGenerate = async () => {
    if (!isKeyValid) {
      toast({ title: "秘钥无效", description: "请先输入并验证有效的秘钥。", variant: "destructive" })
      setIsSupportModalOpen(true)
      return
    }
    if (!uploadedImage) {
      toast({ title: "未上传图片", description: "请先上传一张图片。", variant: "destructive" })
      return
    }
    if (!selectedStyle) {
      toast({ title: "未选择风格", description: "请选择一个图片风格。", variant: "destructive" })
      return
    }

    setGenerationStatus("loading")
    setGeneratedImageUrl(null)
    setErrorMessage(null)
    setIsUploading(true) // Indicate start of upload

    // 1. Upload Image
    const formData = new FormData()
    formData.append("image", uploadedImage)

    let imagePath = ""
    try {
      toast({ title: "正在上传图片...", description: "请稍候。" })
      const uploadResponse = await fetch("/api/upload-image", {
        method: "POST",
        body: formData,
      })

      const uploadData = await uploadResponse.json()
      if (!uploadResponse.ok || !uploadData.filePath) {
        throw new Error(uploadData.message || "图片上传失败。")
      }
      imagePath = uploadData.filePath
      toast({ title: "图片上传成功!", description: "准备进行风格化处理..." })
    } catch (error: any) {
      console.error("Image upload error:", error)
      setErrorMessage(error.message || "图片上传过程中发生错误。")
      setGenerationStatus("error")
      setIsUploading(false)
      toast({ title: "上传失败", description: error.message || "图片上传失败，请重试。", variant: "destructive" })
      return
    } finally {
      setIsUploading(false) // Indicate end of upload
    }

    // 2. Stylize Image
    try {
      toast({ title: "正在风格化图片...", description: "AI正在创作中，这可能需要一点时间。" })
      const stylizeResponse = await fetch("/api/stylize-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imagePath, styleId: selectedStyle, apiKey }), // Pass apiKey for backend validation/consumption
      })

      const stylizeData = await stylizeResponse.json()

      if (!stylizeResponse.ok || !stylizeData.stylizedImageUrl) {
        throw new Error(stylizeData.message || "图片风格化失败。")
      }

      setGeneratedImageUrl(stylizeData.stylizedImageUrl)
      setGenerationStatus("success")
      toast({ title: "生成成功！", description: "图片已成功风格化。" })
    } catch (error: any) {
      console.error("Image stylize error:", error)
      setErrorMessage(error.message || "图片风格化过程中发生错误。")
      setGenerationStatus("error")
      toast({ title: "生成失败", description: error.message || "图片风格化失败，请重试。", variant: "destructive" })
    }
  }

  const handleDownload = () => {
    if (generatedImageUrl) {
      const link = document.createElement("a")
      link.href = generatedImageUrl
      link.download = `picmagic_stylized_${Date.now()}.png` // Or use original file name + style
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      toast({ title: "下载已开始", description: "图片正在下载..." })
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-muted/20">
      <header>
        <KeyValidator
          apiKey={apiKey}
          setApiKey={setApiKey}
          isKeyValid={isKeyValid}
          setIsKeyValid={setIsKeyValid}
          onOpenSupportModal={() => setIsSupportModalOpen(true)}
        />
      </header>

      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <ImageUploader onImageUpload={setUploadedImage} uploadedImage={uploadedImage} />
            <StyleSelector selectedStyle={selectedStyle} onStyleSelect={setSelectedStyle} />
            <Button
              onClick={handleGenerate}
              disabled={
                generationStatus === "loading" || isUploading || !isKeyValid || !uploadedImage || !selectedStyle
              }
              className="w-full py-6 text-lg"
              size="lg"
            >
              {isUploading ? <Upload className="mr-2 h-5 w-5 animate-pulse" /> : <Wand2 className="mr-2 h-5 w-5" />}
              {isUploading ? "上传中..." : generationStatus === "loading" ? "生成中..." : "生成图片"}
            </Button>
            <p className="text-xs text-center text-muted-foreground">
              ⚠️ 每张高清图生成将消耗1次秘钥，请确认后再点击生成。
            </p>
          </div>

          <div className="lg:sticky lg:top-24 h-[calc(100vh-10rem)] lg:h-auto">
            {" "}
            {/* Adjust height for stickiness */}
            <ResultDisplay
              status={generationStatus}
              imageUrl={generatedImageUrl}
              errorMessage={errorMessage}
              onRetry={handleGenerate}
              onDownload={handleDownload}
            />
          </div>
        </div>
      </main>

      <SupportModal isOpen={isSupportModalOpen} onOpenChange={setIsSupportModalOpen} />
    </div>
  )
}
